package com.tech.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.servletr.ConnectionProvider;
import com.tech.dao1.UserDao;
import com.tech.entities.Message;
import com.tech.entities.User;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String userEmail = request.getParameter("uemail");
		String userPassword = request.getParameter("upass");
		
		UserDao dao = new UserDao(ConnectionProvider.getConnection());
		
		User u = dao.getUserByEmailAndPassword(userEmail, userPassword);
		
		if(u==null) {
			//login......
			//error
			//out.println("Invalid details, try again");
			
			Message msg = new Message("Invalid details, try with another","error","alert-danger");
			HttpSession s = request.getSession();
			s.setAttribute("msg", msg);
			response.sendRedirect("login.jsp");
		}else {
			
			if (u.getRole().equals("admin")) {
                //admin:-admin.jsp
                response.sendRedirect("admin.jsp");
            } else if (u.getRole().equals("student")) {
                //normal :normal.jsp
                response.sendRedirect("profile.jsp");
            }
			
			//login success
			HttpSession s = request.getSession();
			s.setAttribute("currentUser", u);
			//response.sendRedirect("profile.jsp");
		}
	}

}
