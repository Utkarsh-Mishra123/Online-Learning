package com.tech.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addquiz123")
public class AddQuiz1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		 // JDBC driver and database URL
        String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost:3306/utkarsh";

        // Database credentials
        String USER = "root";
        String PASS = "Utkarsh$2002";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Register JDBC driver
            Class.forName(JDBC_DRIVER);

            // Open a connection
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // Extract parameters from the request
            String qname = request.getParameter("QuizTitle");
            String markone = request.getParameter("mark");
            String negmark = request.getParameter("negativemark");
            String ques = request.getParameter("question");
            String subjid = request.getParameter("Subject");
           


            // Create SQL query
            String sql = "INSERT INTO quiz (quiz_name, mark_of_one, neg_mark, questions, subject_name) VALUES (?,?,?,?,?)";

            // Create prepared statement
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, qname);
            stmt.setString(2, markone);
            stmt.setString(3, negmark);
            stmt.setString(4, ques);
            stmt.setString(5, subjid);
            

            // Execute the statement
            int rowsAffected = stmt.executeUpdate();

            // Check if the subject was added successfully
            if (rowsAffected > 0) {
            	response.sendRedirect("admin.jsp");
            } else {
                out.println("<h2>Failed to add subject</h2>");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                // Close resources
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
	}

}